Welcome to your new Rocket Trajectory Simulator where you can model anything from a 50cm model rocket to a Saturn 5.
Our program displays altitude, velocity and drag graphs for each simulation and our timestamps are set at 0.05sec.
We model the actual temperature, pressure, density and gravity at each time stamp to ensure reliability. 
The functionality of our program is limited to fixed thrust engines and Earth trajectories, but come back soon for version 2.0!
